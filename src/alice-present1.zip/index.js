const { reply } = require('./alice-renderer')

module.exports.handler = async (event, context) => {
    const {version, session, request} = event;

    let text = '';
    if (request['original_utterance'].length > 0) {
        return reply `${request['original_utterance']}`;
    }
    return reply `Меня зовут Оксана, я помогу Вам с выбором подарка. Кому будем дарить?`
};